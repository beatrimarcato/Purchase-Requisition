window.onload = initialize;

function initialize(){
    
    var buttonEnter = document.getElementById("buttonEnter");
   
    buttonEnter.onclick = password_login(); 
    
}

function password_login(){ /*acesso de login*/
   
    var textboxLogin = document.getElementById("textboxLogin");
    var textboxPassword = document.getElementById("textboxPassword");
    
    var validate = true;
    
    if (textboxLogin.value == "") {
        textboxLogin.style.backgroundColor = "#FF0000";
      
        validate = false;
    }
    
    if (textboxPassword.value == "") {
        textboxPassword.style.backgroundColor = "#FF0000";
      
        validate = false;
    }
    
    return validate;
}
