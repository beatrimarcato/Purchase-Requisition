window.onload = initialize;

function initialize(){
    
    var btSend = document.getElementById("btSend");
    btSend.onclick = access_people;
    
    var btClear = document.getElementById("btClear");
    btClear.onclick = clean;
    
}

function access_people(){ /*cadastro pessoal*/
    var textBoxname = document.getElementById("textBoxname");
    var textBoxdia = document.getElementById("textBoxdia");
    var textBoxmes = document.getElementById("textBoxmes");
    var textBoxano = document.getElementById("textBoxano");
    var textBoxrg = document.getElementById("textBoxrg");
    var textBoxcpf = document.getElementById("textBoxcpf");
    var textBoxcpf2 = document.getElementById("textBoxcpf2");
    
    var validate = true;

    if (textBoxname.value == "") {
        textBoxname.style.backgroundColor = "#FF0000";
        
        validate = false;
    }

    if (textBoxdia.value == "") {
        textBoxdia.style.backgroundColor = "#FF0000";

        validate = false;
    }

    if (textBoxmes.value == "") {
        textBoxmes.style.backgroundColor = "#FF0000";

        validate = false;
    }

    if (textBoxano.value == "") {
        textBoxano.style.backgroundColor = "#FF0000";

        validate = false;
    }

    if (textBoxrg.value == "") {
        textBoxrg.style.backgroundColor = "#FF0000";

        validate = false;
    }
    
    if (textBoxcpf.value == "") {
        textBoxcpf.style.backgroundColor = "#FF0000";

        validate = false;
    }
    
    if (textBoxcpf2.value == "") {
        textBoxcpf2.style.backgroundColor = "#FF0000";

        validate = false;
    }
    
    access_professional();
    access_login();
    
    return validate;
    
}

function access_professional(){ /*cadastro profissional*/
    
    var textBoxinstituicao = document.getElementById("textBoxinstituicao");
    var textBoxrua = document.getElementById("textBoxrua");
    var textBoxnumero = document.getElementById("textBoxnumero");
    var textBoxestado = document.getElementById("textBoxestado");
    var textBoxcidade = document.getElementById("textBoxcidade");
    var textBoxcep = document.getElementById("textBoxcep");
    var textBoxcep2 = document.getElementById("textBoxcep2");
    var textBoxnivel = document.getElementById("textBoxnivel");
    
    var validate = true;
    
    if (textBoxinstituicao.value == "") {
        textBoxinstituicao.style.backgroundColor = "#FF0000";
       
        validate = false;
    }
    
    if (textBoxnumero.value == "") {
        textBoxnumero.style.backgroundColor = "#FF0000";
       
        validate = false;
    }
    
     if (textBoxrua.value == "") {
        textBoxrua.style.backgroundColor = "#FF0000";
       
        validate = false;
    }
    
    if (textBoxestado.value == "") {
        textBoxestado.style.backgroundColor = "#FF0000";
       
        validate = false;
    }
    
    if (textBoxcidade.value == "") {
        textBoxcidade.style.backgroundColor = "#FF0000";
       
        validate = false;
    }
    
    if (textBoxcep.value == "") {
        textBoxcep.style.backgroundColor = "#FF0000";
       
        validate = false;
    }
    
    if (textBoxcep2.value == "") {
        textBoxcep2.style.backgroundColor = "#FF0000";
       
        validate = false;
    }
    
    if (textBoxnivel.value == "") {
        textBoxnivel.style.backgroundColor = "#FF0000";
       
        validate = false;
    }
    
}

function access_login(){ /*cadastro para login *MUITO IMPORTANTE**/
    
    var textBoxemail = document.getElementById("textBoxemail");
    var file_imagem = document.getElementById("file_imagem");
    var textBoxlogin = document.getElementById("textBoxlogin");
    var textBoxpass = document.getElementById("textBoxpass");
    var textBoxpassconfirm = document.getElementById("textBoxpassconfirm");
    var textBoxcep = document.getElementById("textBoxcep");
    var textBoxcep2 = document.getElementById("textBoxcep2");
    var textBoxnivel = document.getElementById("textBoxnivel");
    
    var validate = true;
    
    if (textBoxemail.value == "") {
        textBoxemail.style.backgroundColor = "#FF0000";
       
        validate = false;
    }
    
     if (file_image.value == "") {
        file_image.style.backgroundColor = "#FF0000";
       
        validate = false;
    }
    
    if (textBoxlogin.value == "") {
        textBoxlogin.style.backgroundColor = "#FF0000";
       
        validate = false;
    }
    
    if (textBoxpass.value == "") {
        textBoxpass.style.backgroundColor = "#FF0000";
       
        validate = false;
    }
    
    if (textBoxpassconfirm.value == "") {
        textBoxpass.style.backgroundColor = "#FF0000";
       
        validate = false;
    }
    
    if (textBoxpassconfirm.value == "") {
        textBoxpass.style.backgroundColor = "#FF0000";
       
        validate = false;
    }
    
    if (textBoxcep.value == "") {
        textBoxcep.style.backgroundColor = "#FF0000";
       
        validate = false;
    }
    
    if (textBoxcep2.value == "") {
        textBoxcep2.style.backgroundColor = "#FF0000";
       
        validate = false;
    }
    
    if (textBoxnivel.value == "") {
        textBoxnivel.style.backgroundColor = "#FF0000";
       
        validate = false;
    }
  
}

function clean() {
    
    var textBoxname = document.getElementById("textBoxname");
    var textBoxdia = document.getElementById("textBoxdia");
    var textBoxmes = document.getElementById("textBoxmes");
    var textBoxano = document.getElementById("textBoxano");
    var textBoxrg = document.getElementById("textBoxrg");
    var textBoxcpf = document.getElementById("textBoxcpf");
    var textBoxcpf2 = document.getElementById("textBoxcpf2");
    var textBoxinstituicao = document.getElementById("textBoxinstituicao");
    var textBoxrua = document.getElementById("textBoxrua");
    var textBoxnumero = document.getElementById("textBoxnumero");
    var textBoxestado = document.getElementById("textBoxestado");
    var textBoxcidade = document.getElementById("textBoxcidade");
    var textBoxcep = document.getElementById("textBoxcep");
    var textBoxcep2 = document.getElementById("textBoxcep2");
    var textBoxnivel = document.getElementById("textBoxnivel");
    var textBoxemail = document.getElementById("textBoxemail");
    var file_imagem = document.getElementById("file_imagem");
    var textBoxlogin = document.getElementById("textBoxlogin");
    var textBoxpass = document.getElementById("textBoxpass");
    var textBoxpassconfirm = document.getElementById("textBoxpassconfirm");
    var textBoxcep = document.getElementById("textBoxcep");
    var textBoxcep2 = document.getElementById("textBoxcep2");
    var textBoxnivel = document.getElementById("textBoxnivel");
    
    var validate = true;
    
    textBoxname.style.backgroundColor = "#FFF";
    textBoxdia.style.backgroundColor = "#FFF";
    textBoxmes.style.backgroundColor = "#FFF";
    textBoxano.style.backgroundColor = "#FFF";
    textBoxrg.style.backgroundColor = "#FFF";
    textBoxcpf.style.backgroundColor = "#FFF";
    textBoxcpf2.style.backgroundColor = "#FFF";
    textBoxinstituicao.style.backgroundColor = "#FFF";
    textBoxrua.style.backgroundColor = "#FFF";
    textBoxnumero.style.backgroundColor = "#FFF";
    textBoxestado.style.backgroundColor = "#FFF";
    textBoxcidade.style.backgroundColor = "#FFF";
    textBoxcep.style.backgroundColor = "#FFF";
    textBoxcep2.style.backgroundColor = "#FFF";
    textBoxnivel.style.backgroundColor = "#FFF";
    textBoxemail.style.backgroundColor = "#FFF";
    file_imagem.style.backgroundColor = "#FFF";
    textBoxlogin.style.backgroundColor = "#FFF";
    textBoxpass.style.backgroundColor = "#FFF";
    textBoxpassconfirm.style.backgroundColor = "#FFF";
    textBoxcep.style.backgroundColor = "#FFF";
    textBoxcep2.style.backgroundColor = "#FFF";
    textBoxnivel.style.backgroundColor = "#FFF";
    
}



